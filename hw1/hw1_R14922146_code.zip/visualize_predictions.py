import torch
import torchvision
from torchvision.transforms import Compose, ToTensor, Normalize
import matplotlib.pyplot as plt
import numpy as np
import random

# 載入您在 model.py 中定義的模型類別
from model import ViT_Classifier, MAE_ViT

# --- 設定區 ---
# 請確認這個路徑是您用 MAE 微調好的模型檔名
MODEL_PATH = 'vit-t-classifier-from_pretrained.pt'
NUM_IMAGES = 10 # 您想要視覺化的圖片數量
# --- 設定區結束 ---

def visualize_predictions():
    # 設定設備
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Using device: {device}")

    # 1. 載入模型
    print(f"Loading model from {MODEL_PATH}...")
    # 載入完整的 ViT_Classifier 物件
    # 注意：我們需要 MAE_ViT 的定義，因為它是 ViT_Classifier 的一部分
    model = torch.load(MODEL_PATH, map_location=device, weights_only=False)
    model.eval() # 設定為評估模式

    # 2. 準備資料集
    transform = Compose([ToTensor(), Normalize(0.5, 0.5)])
    val_dataset = torchvision.datasets.CIFAR10('data', train=False, download=True, transform=transform)
    class_names = val_dataset.classes
    
    # 隨機挑選 N 張圖片的索引
    indices = random.sample(range(len(val_dataset)), NUM_IMAGES)

    # 準備繪圖
    fig, axes = plt.subplots(2, (NUM_IMAGES + 1) // 2, figsize=(15, 6))
    axes = axes.flatten()

    for i, idx in enumerate(indices):
        # 取得圖片和真實標籤
        image, label_idx = val_dataset[idx]
        true_label = class_names[label_idx]

        # 3. 進行預測
        with torch.no_grad():
            # 模型需要一個批次維度 (batch dimension)，所以用 unsqueeze(0)
            logits = model(image.unsqueeze(0).to(device))
            pred_idx = logits.argmax(dim=-1).item()
            pred_label = class_names[pred_idx]

        # 4. 繪製結果
        # 將圖片反正規化 (denormalize) 以便正確顯示
        # (從 [-1, 1] 轉換回 [0, 1])
        img_display = image.permute(1, 2, 0).cpu().numpy()
        img_display = 0.5 * img_display + 0.5
        img_display = np.clip(img_display, 0, 1)

        ax = axes[i]
        ax.imshow(img_display)
        ax.set_title(f"True: {true_label}\nPred: {pred_label}", 
                     color=("green" if true_label == pred_label else "red"))
        ax.axis('off')

    # 隱藏多餘的子圖
    for j in range(i + 1, len(axes)):
        axes[j].axis('off')

    plt.tight_layout()
    # 儲存圖片
    output_filename = 'classifier_predictions.png'
    plt.savefig(output_filename)
    print(f"Visualization saved to {output_filename}")


if __name__ == '__main__':
    visualize_predictions()