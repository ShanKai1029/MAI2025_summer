import torch
import torchvision
from torchvision.transforms import Compose, ToTensor, Normalize
from torchvision.utils import save_image
import matplotlib.pyplot as plt
import numpy as np
import random

# 載入您在 model.py 中定義的模型類別
from model import MAE_ViT

# --- 設定區 ---
# 請將此路徑改為您想視覺化的 MAE 預訓練模型檔名
# 例如：'vit-mae-d4.pt', 'vit-mae-mask-block.pt' 等
MODEL_PATH = 'vit-mae-mask-block.pt' 
NUM_IMAGES = 2 # 您想要視覺化的圖片數量
# --- 設定區結束 ---

def visualize_reconstruction():
    # 設定設備
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Using device: {device}")

    # 1. 載入模型
    print(f"Loading model from {MODEL_PATH}...")
    # 載入完整的 MAE_ViT 物件
    model = torch.load(MODEL_PATH, map_location=device, weights_only=False)
    # 修正舊模型缺少 strategy 屬性的問題
    if not hasattr(model.encoder.shuffle, 'strategy'):
        model.encoder.shuffle.strategy = 'random'
    model.eval() # 設定為評估模式

    # 2. 準備資料集
    transform = Compose([ToTensor(), Normalize(0.5, 0.5)])
    val_dataset = torchvision.datasets.CIFAR10('data', train=False, download=True, transform=transform)

    # 固定隨機種子以確保每次選到相同的圖片
    random.seed(42)
    # 隨機挑選 N 張圖片的索引
    indices = random.sample(range(len(val_dataset)), NUM_IMAGES)
    
    # 從資料集中取出圖片，並組合成一個批次
    images = torch.stack([val_dataset[i][0] for i in indices]).to(device)

    # 3. 進行重建
    with torch.no_grad():
        predicted_images, mask = model(images)
        # 將重建的圖像與可見部分拼接，得到完整的輸出
        reconstructed_images = predicted_images * mask + images * (1 - mask)

    # 4. 準備繪圖
    # 將圖片反正規化 (denormalize) 以便正確顯示
    images = (images.cpu() * 0.5 + 0.5).numpy()
    reconstructed_images = (reconstructed_images.cpu() * 0.5 + 0.5).numpy()
    mask = mask.cpu().numpy()

    # 產生遮罩後的圖片 (只顯示可見部分)
    masked_images = images * (1 - mask)

    # 繪製結果
    fig, axes = plt.subplots(NUM_IMAGES, 2, figsize=(6, NUM_IMAGES * 3))

    for i in range(NUM_IMAGES):
        # 繪製遮罩後的圖片
        ax = axes[i, 0]
        ax.imshow(np.transpose(masked_images[i], (1, 2, 0)))
        ax.set_title("Masked Image")
        ax.axis('off')

        # 繪製模型重建的圖片
        ax = axes[i, 1]
        ax.imshow(np.transpose(reconstructed_images[i], (1, 2, 0)))
        ax.set_title("Reconstructed Image")
        ax.axis('off')

    plt.tight_layout()
    # 儲存圖片
    output_filename = f'reconstruction_comparison_{os.path.basename(MODEL_PATH).split(".")[0]}.png'
    plt.savefig(output_filename)
    print(f"Visualization saved to {output_filename}")


if __name__ == '__main__':
    # 需要 os 模組來處理檔名
    import os
    visualize_reconstruction()