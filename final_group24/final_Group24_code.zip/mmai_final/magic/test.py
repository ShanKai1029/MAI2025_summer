# =====================================================
# test.py
# MagicBrush LoRA Evaluation (Metrics: LPIPS, CLIP-S, CLIP-I)
# =====================================================

import os
import json
import argparse
import numpy as np
from PIL import Image
from tqdm import tqdm

import torch
import torch.nn.functional as F
from torchvision import transforms

# Diffusers & Peft
from diffusers import StableDiffusionInpaintPipeline
from peft import PeftModel

# Metrics
import lpips
import clip

# -----------------------------------------------------
# Utils
# -----------------------------------------------------
def load_image(path, mode="RGB"):
    return Image.open(path).convert(mode)

def resolve_path(img_dir: str, p: str) -> str:
    if os.path.isabs(p) or p.startswith("data/") or p.startswith("./") or p.startswith("../"):
        return p
    return os.path.join(img_dir, p)

def compute_mean_std(values):
    arr = np.array(values, dtype=np.float32)
    return float(arr.mean()), float(arr.std())


def _clip_cosine(a: torch.Tensor, b: torch.Tensor) -> float:
    a = F.normalize(a, dim=-1)
    b = F.normalize(b, dim=-1)
    return float((a * b).sum(dim=-1).item())

# -----------------------------------------------------
# Main
# -----------------------------------------------------
def main(args):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.float16 if device == "cuda" else torch.float32

    os.makedirs(args.out_dir, exist_ok=True)

    # -------------------------
    # 1. Load Models (Inference + Metrics)
    # -------------------------
    print("[INFO] Loading Metrics Models...")
    
    # CLIP
    clip_model, clip_preprocess = clip.load("ViT-B/32", device=device)
    clip_model.eval()

    # Transforms
    tf_tensor = transforms.ToTensor()
    tf_resize_512 = transforms.Resize((512, 512)) # Standardize for metrics

    # PowerPaint Pipeline
    print(f"[INFO] Loading Base Model: {args.model_id}")
    pipe_base = StableDiffusionInpaintPipeline.from_pretrained(
        args.model_id,
        torch_dtype=dtype,
        safety_checker=None,
    ).to(device)
    pipe_base.safety_checker = None
    pipe_base.set_progress_bar_config(disable=True)
    pipe_base.unet.eval()
    pipe_base.vae.eval()

    # LoRA Pipeline (Re-use same base, just attach adapter)
    # 為了比較方便，我們這裡載入第二個 pipeline 或者動態 switch
    # 為了記憶體考量，我們這裡建立兩個 pipeline 有點浪費，但為了 code 簡單，我們暫時分開跑
    # 或者比較好的做法：跑完 Base 再掛載 LoRA 跑一次。這裡採用「同時載入兩個」如果是 24G VRAM 應該夠
    
    pipe_lora = StableDiffusionInpaintPipeline.from_pretrained(
        args.model_id,
        torch_dtype=dtype,
        safety_checker=None,
    ).to(device)
    pipe_lora.unet = PeftModel.from_pretrained(pipe_lora.unet, args.lora_path)
    pipe_lora.safety_checker = None
    pipe_lora.set_progress_bar_config(disable=True)
    pipe_lora.unet.eval()
    pipe_lora.vae.eval()
    pipe_lora.to(device)

    # -------------------------
    # 2. Load Meta
    # -------------------------
    with open(args.meta_path, "r") as f:
        samples = json.load(f)
        if isinstance(samples, dict) and "samples" in samples:
            samples = samples["samples"] # Handle standard MagicBrush json format

    if args.num_samples is not None:
        samples = samples[: args.num_samples]

    print(f"[INFO] Evaluating on {len(samples)} samples")

    # Metrics Storage
    metrics = {
        "base": { "clip_s": [], "clip_i": []},
        "lora": { "clip_s": [], "clip_i": []}
    }

    # -------------------------
    # 3. Inference Loop
    # -------------------------
    for idx, s in enumerate(tqdm(samples, desc="MagicBrush Eval")):
        #out_dir = os.path.join(args.out_dir, f"{idx:04d}")
        #os.makedirs(out_dir, exist_ok=True)

        # Load Data
        source_path = resolve_path(args.img_dir, s["source"])
        mask_path   = resolve_path(args.img_dir, s["mask"])
        target_path = resolve_path(args.img_dir, s.get("target", ""))
        prompt      = s["prompt"]
        
        # MagicBrush Prompt + P_obj (Essential!)
        if "P_obj" not in prompt and "P_ctxt" not in prompt:
             prompt_in = f"{prompt} P_obj"
        else:
             prompt_in = prompt

        try:
            source = load_image(source_path, "RGB").resize((512, 512))
            mask_raw = load_image(mask_path, "L").resize((512, 512), Image.NEAREST)
            
            # Mask Preproc: 0(Black)=Keep, 255(White)=Inpaint (Diffusers format)
            # 你的 mask 轉換邏輯: 255 if p==0 else 0 (把原本黑色變成白色去修)
            mask = mask_raw.point(lambda p: 255 if p == 0 else 0)
            
            has_target = False
            if target_path and os.path.exists(target_path):
                target = load_image(target_path, "RGB").resize((512, 512))
                has_target = True
        except Exception as e:
            print(f"Skipping {idx}: Load error {e}")
            continue

        # Inference
        with torch.no_grad():
            # 1. Base
            out_base = pipe_base(
                prompt=prompt_in, image=source, mask_image=mask,
                num_inference_steps=args.steps, guidance_scale=args.guidance_scale
            ).images[0]

            # 2. LoRA
            out_lora = pipe_lora(
                prompt=prompt_in, image=source, mask_image=mask,
                num_inference_steps=args.steps, guidance_scale=args.guidance_scale
            ).images[0]

        # -------------------------
        # Compute Metrics
        # -------------------------
        # Prepare Tensors
        # Shape: [1, 3, H, W]
        src_t = tf_tensor(source).unsqueeze(0).to(device)
        mask_t = tf_tensor(mask).unsqueeze(0).to(device) # 1=Edit, 0=Bg
        mask_t_3 = mask_t.repeat(1, 3, 1, 1)
        bg_mask_3 = 1.0 - mask_t_3

        # Prepare Text for CLIP
        clip_txt = clip.tokenize([prompt]).to(device) # Use original prompt for scoring

        # Helper to compute for one image
        def calc_single(pred_img, model_key):
            pred_t = tf_tensor(pred_img).unsqueeze(0).to(device)
            
            # A. Masked LPIPS (vs Target if avail, else skip)
            if has_target:
                # D. CLIP-I (vs Target)
                # Resize for CLIP
                pred_clip = clip_preprocess(pred_img).unsqueeze(0).to(device)
                tgt_clip  = clip_preprocess(target).unsqueeze(0).to(device)
                ci = _clip_cosine(clip_model.encode_image(pred_clip), clip_model.encode_image(tgt_clip))
                metrics[model_key]["clip_i"].append(ci)
            # C. CLIP Score (vs Text)
            pred_clip = clip_preprocess(pred_img).unsqueeze(0).to(device)
            cs = _clip_cosine(clip_model.encode_image(pred_clip), clip_model.encode_text(clip_txt))
            metrics[model_key]["clip_s"].append(cs)

        calc_single(out_base, "base")
        calc_single(out_lora, "lora")

        # Save Visuals
        #source.save(os.path.join(out_dir, "source.png"))
        #mask.save(os.path.join(out_dir, "mask.png"))
        #if has_target:
            #target.save(os.path.join(out_dir, "target.png"))
        #out_base.save(os.path.join(out_dir, "out_base.png"))
        #out_lora.save(os.path.join(out_dir, "out_lora.png"))
        #with open(os.path.join(out_dir, "prompt.txt"), "w") as f:
            #f.write(f"Prompt: {prompt}\nInput: {prompt_in}")

    # -------------------------
    # 4. Save Summary
    # -------------------------
    final_summary = {}
    for m_key in metrics:
        final_summary[m_key] = {}
        for metric_name, values in metrics[m_key].items():
            if len(values) > 0:
                mean, std = compute_mean_std(values)
                final_summary[m_key][metric_name] = {"mean": mean, "std": std}
    
    out_json = os.path.join(args.out_dir, "summary_magicbrush.json")
    with open(out_json, "w") as f:
        json.dump(final_summary, f, indent=2)

    print(f"\n[DONE] Evaluation finished. Summary saved to {out_json}")
    
    # Print simple report
    print("-" * 40)
    print("      Metric      |   Base   |   LoRA   ")
    print("-" * 40)
    # 這裡只印 Mean，詳細看 JSON
    def get_m(k, m):
        return final_summary.get(k, {}).get(m, {}).get("mean", 0.0)
    print(f" CLIP Score   (↑) | {get_m('base','clip_s'):.4f} | {get_m('lora','clip_s'):.4f}")
    print(f" CLIP-I       (↑) | {get_m('base','clip_i'):.4f} | {get_m('lora','clip_i'):.4f}")
    print("-" * 40)


# -----------------------------------------------------
# Args
# -----------------------------------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser("MagicBrush LoRA Eval")
    parser.add_argument("--meta_path", type=str, required=True)
    parser.add_argument("--img_dir", type=str, default="")
    parser.add_argument("--out_dir", type=str, default="./eval_magicbrush")
    parser.add_argument("--model_id", type=str, default="Sanster/PowerPaint-V1-stable-diffusion-inpainting")
    parser.add_argument("--lora_path", type=str, required=True)
    parser.add_argument("--num_samples", type=int, default=50) # Set reasonable default for quick test
    parser.add_argument("--steps", type=int, default=50)
    parser.add_argument("--guidance_scale", type=float, default=7.5)

    args = parser.parse_args()
    main(args)