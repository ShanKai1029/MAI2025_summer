#!/bin/bash

# =================================================================
# MagicBrush Ablation Study / Evaluation Script
# =================================================================

# 1. GPU 設定
export CUDA_VISIBLE_DEVICES=0

# 2. 路徑設定 (請根據你的實際路徑修改)
# MagicBrush 的 Meta JSON 檔 (通常是 dev.json 或 test.json)
MB_META_PATH="data/meta/dev_meta.json"

# MagicBrush 的圖片資料夾
MB_IMG_DIR="data/images/dev"

# 你的 LoRA 權重路徑 (指向你剛剛訓練好的 .safetensors 或資料夾)
# 例如: outputs/6hrinv_mask_slide_final_20251223_1400/pytorch_lora_weights.safetensors
MY_LORA_PATH="outputs/ablation1_rk16_magic_brush_20251222_1443"
#在train裡面
# 3. 輸出與參數設定
# 輸出資料夾 (會自動建立)
OUT_DIR="evaluation_results/magicbrush_test_with_lora"

# 測試參數
NUM_SAMPLES=1000       # 要測幾張圖 (MagicBrush Dev set 通常有幾百張，建議設 50-100)
STEPS=50             # 推論步數 (通常 30-50 就夠了，100 會跑比較久)
CFG_SCALE=7.5        # Guidance Scale

echo "========================================================="
echo "Starting MagicBrush Evaluation"
echo "Meta:      $MB_META_PATH"
echo "LoRA:      $MY_LORA_PATH"
echo "Output:    $OUT_DIR"
echo "========================================================="

# 4. 執行 Python Script
python test.py \
    --meta_path "$MB_META_PATH" \
    --img_dir "$MB_IMG_DIR" \
    --out_dir "$OUT_DIR" \
    --lora_path "$MY_LORA_PATH" \
    --num_samples $NUM_SAMPLES \
    --steps $STEPS \
    --guidance_scale $CFG_SCALE

echo "========================================================="
echo "Evaluation Finished! Results saved to $OUT_DIR"
echo "========================================================="