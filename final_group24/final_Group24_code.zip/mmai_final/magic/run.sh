#!/bin/bash

# ============================================
# Ablation 1: MagicBrush Training Launcher
# ============================================

# 1. GPU 設定
export CUDA_VISIBLE_DEVICES=1

# 2. 實驗名稱 (建議改個名字區分，例如 ablation_magic)
EXP_NAME="ablation1_rk16_magic_brush"
DATE_STR=$(date +%Y%m%d_%H%M)

# 3. 關鍵路徑設定 (根據你的截圖結構修改)
# 注意: 請確認你的 python 檔名是 train_magic.py 還是 train_magic_ablation.py
PYTHON_SCRIPT="train_magic.py"

# Metadata 位置
META_FILE="data/meta/train_meta.json"

# 圖片根目錄
# 假設 json 裡面的路徑是 "train/xxx.jpg"，這裡設 "data/images" 就可以串接起來
# 如果 json 裡面只有檔名 "xxx.jpg"，這裡要改成 "data/images/train"
INPUT_DIR="."

# 輸出位置
OUTPUT_DIR="outputs/${EXP_NAME}_${DATE_STR}"
LOG_DIR="runs/${EXP_NAME}_${DATE_STR}"

# 4. 訓練超參數
BATCH_SIZE=8       # 顯存夠大可以開 4 或 8
LR=1e-4
EPOCHS=50
IMAGE_SIZE=512
LORA_RANK=16

echo "========================================================="
echo "🚀 Starting Ablation Study: $EXP_NAME"
echo "Script:           $PYTHON_SCRIPT"
echo "Meta File:        $META_FILE"
echo "Image Root:       $INPUT_DIR"
echo "Output Directory: $OUTPUT_DIR"
echo "========================================================="

# 5. 執行 Python
# [重要] 這裡執行的是 train_magic.py (沒有 bbox, 白色 mask)
python "$PYTHON_SCRIPT" \
    --meta_path "$META_FILE" \
    --input_dir "$INPUT_DIR" \
    --output_dir "$OUTPUT_DIR" \
    --log_dir "$LOG_DIR" \
    --batch_size $BATCH_SIZE \
    --lr $LR \
    --epochs $EPOCHS \
    --image_size $IMAGE_SIZE \
    --lora_rank $LORA_RANK \
    --visualize_every 500 \
    --print_every 20 \
    --val_every 500 \
    --num_workers 4 \
    --max_train_time 21600

echo "✅ Training finished!"