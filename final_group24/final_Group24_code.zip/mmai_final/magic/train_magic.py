# =====================================================
# train_powerpaint_mask.py (Final Version with Input Dir)
# =====================================================

import json
import time
import os
import argparse
from collections import deque 

import torch
import torch.nn.functional as F
from torch.cuda.amp import autocast, GradScaler
from torch.utils.data import Dataset, DataLoader
from torch.utils.tensorboard import SummaryWriter
from torchvision import transforms
from torchvision.transforms.functional import to_pil_image
from torchvision.utils import make_grid
from PIL import Image

from diffusers import StableDiffusionInpaintPipeline, DDPMScheduler
from peft import LoraConfig, get_peft_model

# -------------------------
# Utils
# -------------------------
def validate(args, pipe, val_loader, writer, global_step, device):
    print(f"\n[INFO] Running Validation at step {global_step}...")
    
    # 建立存檔資料夾: outputs/val_step_XXXXXX
    # 這樣就會符合你要求的 expname_stepxx 結構 (假設 output_dir 就是 expname)
    save_dir = os.path.join(args.output_dir, f"val_step_{global_step:06d}")
    os.makedirs(save_dir, exist_ok=True)

    pipe.unet.eval()
    
    # 抓第一筆資料來視覺化 (只抓第一張)
    first_batch = None
    
    with torch.no_grad():
        for i, batch in enumerate(val_loader):
            # 只取第一筆做視覺化，其他的可以拿來算 Loss (這裡簡化只取第一筆)
            if i == 0:
                first_batch = {
                    "source": batch["source"][0],
                    "target": batch["target"][0],
                    "mask": batch["mask"][0],
                    "prompt": batch["prompt"][0]
                }
                break # 抓到一張就夠了，如果要算準確 Loss 可以拿掉 break 跑完迴圈

    # --- Generate & Save Image ---
    if first_batch is not None:
        print(f"[INFO] Saving visualization to {save_dir}")
        
        # 1. 準備 Tensor -> PIL
        src_pil = to_pil_image(denormalize_to_01(first_batch["source"]))
        tgt_pil = to_pil_image(denormalize_to_01(first_batch["target"]))
        mask_pil = to_pil_image(first_batch["mask"]) # Mask 是 0~1
        p_text = first_batch["prompt"]

        # 2. 存文字與原始圖
        with open(os.path.join(save_dir, "prompt.txt"), "w") as f:
            f.write(p_text)
            
        src_pil.save(os.path.join(save_dir, "source.png"))
        tgt_pil.save(os.path.join(save_dir, "target.png"))
        mask_pil.save(os.path.join(save_dir, "mask.png"))

        # 3. 執行推論 (Inference)
        # 暫時啟用 VAE/TextEncoder 進行生成
        gen_image = pipe(
            prompt=p_text,
            image=src_pil,
            mask_image=mask_pil,
            num_inference_steps=30,
            guidance_scale=7.5,
        ).images[0]
        
        # 4. 存結果圖
        gen_image.save(os.path.join(save_dir, "output.png"))
    
    pipe.unet.train() # 切換回 Training Mode

# =========================================================
# 改動 1 end
# =========================================================

def denormalize_to_01(tensor: torch.Tensor) -> torch.Tensor:
    """Denormalize tensor from [-1, 1] range back to [0, 1]."""
    tensor = (tensor + 1.0) / 2.0
    return tensor.clamp(0, 1)

# -------------------------
# Dataset
# -------------------------
class SlideCropDataset(Dataset):
    # ⬇️ NEW: 接收 input_dir 參數
    def __init__(self, meta_path, input_dir, image_size=512):
        self.input_dir = input_dir  # 儲存根目錄路徑
        
        with open(meta_path, "r") as f:
            self.samples = json.load(f)["samples"]

        self.img_tf = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize([0.5], [0.5]),
        ])

        self.mask_tf = transforms.Compose([
            transforms.Resize((image_size, image_size), interpolation=Image.NEAREST),
            transforms.ToTensor(),
        ])

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        s = self.samples[idx]

        # 1. Paths
        src_path = os.path.join(self.input_dir, s["source"])
        mask_path = os.path.join(self.input_dir, s["mask"])
        tgt_path = os.path.join(self.input_dir, s["target"])

        # 2. Load Images (全部轉成 RGB 以便計算差異)
        try:
            source_full = Image.open(src_path).convert("RGB")
            mask_full_img = Image.open(mask_path).convert("RGB") # 注意：這裡讀成 RGB 圖片，不是 L
            target_full = Image.open(tgt_path).convert("RGB")
        except FileNotFoundError as e:
            print(f"[WARN] File not found: {e}")
            return self.__getitem__((idx + 1) % len(self))

        # 3. No Crop (Resize)
        source_crop = source_full
        mask_overlay = mask_full_img # 這是你的 "疊圖"
        target_crop = target_full

        # 4. Transform (Resize & Tensor)
        # 這裡我們需要一個不包含 Normalize 的 transform 來算差異
        # 所以我們手動 resize 並轉 tensor
        
        resize = transforms.Resize((512, 512))
        to_tensor = transforms.ToTensor()
        norm = transforms.Normalize([0.5], [0.5])

        # Source & Target 正常處理
        src_resized = resize(source_crop)
        tgt_resized = resize(target_crop)
        
        source_tensor = norm(to_tensor(src_resized))
        target_tensor = norm(to_tensor(tgt_resized))

        # -----------------------------------------------------------
        # [CRITICAL FIX] 使用 "差異法" 產生 Mask
        # -----------------------------------------------------------
        # 1. 把 Source 和 MaskOverlay 都轉成 Tensor (0~1)
        src_t = to_tensor(src_resized)     # [3, 512, 512]
        mask_ov_t = to_tensor(resize(mask_overlay)) # [3, 512, 512]

        # 2. 計算差異 (Absolute Difference)
        # 在 RGB 三個通道上算差異，只要任一通道有變，就是 Mask
        diff = torch.abs(src_t - mask_ov_t) # [3, 512, 512]
        
        # 3. 轉成單通道灰階 (取 RGB 差異的最大值，或平均值)
        diff_gray = diff.mean(dim=0, keepdim=True) # [1, 512, 512]

        # 4. 二值化：只要差異大於一點點 (例如 0.05)，就是 Mask
        # 這樣背景(差異0)會變黑，塗鴉處(差異大)會變白
        mask_tensor = (diff_gray > 0.05).float()
        # -----------------------------------------------------------

        # Prompt Trigger
        prompt = s["prompt"]
        if "P_obj" not in prompt and "P_ctxt" not in prompt:
            prompt = f"{prompt} P_obj"

        return {
            "source": source_tensor,
            "mask": mask_tensor,   # 這現在是完美的 Binary Mask 了
            "target": target_tensor,
            "prompt": prompt,
        }
# -------------------------
# Main Training Function
# -------------------------
def main(args):
    # Setup directories
    os.makedirs(args.output_dir, exist_ok=True)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    writer = SummaryWriter(args.log_dir)

    print(f"[INFO] Loading Model: {args.model_id}")
    pipe = StableDiffusionInpaintPipeline.from_pretrained(
        args.model_id,
        torch_dtype=torch.float32, 
        safety_checker=None
    ).to(device)

    # Freeze Base Model
    pipe.vae.requires_grad_(False)
    pipe.text_encoder.requires_grad_(False)
    pipe.unet.requires_grad_(False)

    # Setup LoRA
    print(f"[INFO] Adding LoRA Adapter (Rank={args.lora_rank})")
    pipe.unet = get_peft_model(
        pipe.unet,
        LoraConfig(
            r=args.lora_rank,
            lora_alpha=args.lora_alpha,
            target_modules=["to_q", "to_k", "to_v"],
            lora_dropout=args.lora_dropout,
        )
    )
    pipe.unet.train()

    # ⬇️ NEW: 傳入 input_dir 給 Dataset
    dataset = SlideCropDataset(args.meta_path, args.input_dir, image_size=args.image_size)
    loader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=True,
    )
    val_loader = DataLoader(dataset, batch_size=1, shuffle=False)
    optimizer = torch.optim.AdamW(pipe.unet.parameters(), lr=args.lr)
    scheduler = DDPMScheduler.from_config(pipe.scheduler.config)
    scaler = GradScaler()

    loss_ma_buf = deque(maxlen=args.ma_window)
    global_step = 0
    start_time = time.time()
    last_print = time.time()

    print(f"[INFO] Start Training for {args.epochs} Epochs...")

    for epoch in range(args.epochs):
        for batch in loader:
            if time.time() - start_time > args.max_train_time:
                print("[INFO] Reached time limit, saving and exiting.")
                pipe.unet.save_pretrained(args.output_dir)
                writer.close()
                return

            source = batch["source"].to(device)
            mask = batch["mask"].to(device)

            with autocast():
                # VAE Encode
                with torch.no_grad():
                    latents = pipe.vae.encode(source).latent_dist.sample()
                    latents = latents * pipe.vae.config.scaling_factor

                # Add Noise
                noise = torch.randn_like(latents)
                timesteps = torch.randint(0, scheduler.config.num_train_timesteps, (latents.shape[0],), device=device).long()
                noisy_latents = scheduler.add_noise(latents, noise, timesteps)

                # Latent Masking
                mask_latent = F.interpolate(mask, size=latents.shape[-2:], mode="nearest")
                masked_latents = latents * (1 - mask_latent)

                # Text Emb
                text_ids = pipe.tokenizer(
                    batch["prompt"], padding="max_length", truncation=True, return_tensors="pt"
                ).input_ids.to(device)
                text_emb = pipe.text_encoder(text_ids)[0]

                # UNet Forward
                unet_input = torch.cat([noisy_latents, mask_latent, masked_latents], dim=1)
                pred = pipe.unet(unet_input, timesteps, encoder_hidden_states=text_emb).sample

                # Loss
                denom = mask_latent.sum().clamp_min(1.0)
                loss = (((pred - noise) ** 2) * mask_latent).sum() / denom

            # Backward
            optimizer.zero_grad()
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            # Logging
            loss_val = loss.item()
            loss_ma_buf.append(loss_val)
            loss_ma = sum(loss_ma_buf) / len(loss_ma_buf)

            if global_step % args.tb_log_every == 0:
                writer.add_scalar("train/loss_raw", loss_val, global_step)
                writer.add_scalar("train/loss_ma100", loss_ma, global_step)
                writer.add_scalar("train/mask_coverage", mask_latent.mean().item(), global_step)
                writer.add_scalar("train/lr", optimizer.param_groups[0]["lr"], global_step)

            if global_step % args.print_every == 0:
                now = time.time()
                print(f"[Epoch {epoch}][Step {global_step}] Loss={loss_val:.4f} | MA={loss_ma:.4f} | dt={now - last_print:.1f}s")
                last_print = now
            
            if global_step > 0 and global_step % args.val_every == 0:
                validate(args, pipe, val_loader, writer, global_step, device)

            # Visualization
            if global_step % args.visualize_every == 0:
                source_vis = denormalize_to_01(batch["source"][0].cpu())
                target_vis = denormalize_to_01(batch["target"][0].cpu())
                mask_vis = batch["mask"][0].cpu().repeat(3, 1, 1)
                
                grid = make_grid([source_vis, target_vis, mask_vis], nrow=3)
                writer.add_image("train/visualization", grid, global_step)
                print(f"[INFO] Visualized at step {global_step}")

            global_step += 1

    print("[INFO] Training Finished. Saving Model...")
    pipe.unet.save_pretrained(args.output_dir)
    writer.close()
    print(f"[DONE] Saved to {args.output_dir}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="PowerPaint LoRA Training Script")
    
    # Paths
    parser.add_argument("--meta_path", type=str, required=True, help="Path to json metadata")
    parser.add_argument("--input_dir", type=str, required=True, help="Root directory for images")  # ⬅️ NEW argument
    parser.add_argument("--output_dir", type=str, default="outputs/powerpaint_lora", help="Where to save model")
    parser.add_argument("--log_dir", type=str, default="runs/powerpaint_lora", help="Tensorboard log dir")
    
    # Model & Training
    parser.add_argument("--model_id", type=str, default="Sanster/PowerPaint-V1-stable-diffusion-inpainting")
    parser.add_argument("--lora_rank", type=int, default=8)
    parser.add_argument("--lora_alpha", type=int, default=16)
    parser.add_argument("--lora_dropout", type=float, default=0.1)
    parser.add_argument("--image_size", type=int, default=512)
    parser.add_argument("--batch_size", type=int, default=2)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--num_workers", type=int, default=4)
    parser.add_argument("--max_train_time", type=int, default=21600)
    parser.add_argument("--val_every", type=int, default=500, help="Run validation and save images every N steps")
    # Logging
    parser.add_argument("--print_every", type=int, default=20)
    parser.add_argument("--tb_log_every", type=int, default=10)
    parser.add_argument("--visualize_every", type=int, default=500)
    parser.add_argument("--ma_window", type=int, default=100)

    args = parser.parse_args()
    main(args)